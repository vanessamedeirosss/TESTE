# Códigos completos — versão GitHub Pages corrigida

## `README.md`
```markdown
# HM-RM — versão revisada

Site do Produto Educacional vinculado à dissertação **Desenvolvimento do Raciocínio Matemático no Ensino Fundamental I mediado pela História da Matemática**.

## Critério desta revisão

A redação das páginas foi revista para permanecer **estritamente fundamentada na versão da dissertação fornecida**. Foram retiradas formulações, recomendações e descrições que não estavam explicitamente sustentadas pelo referencial teórico, pelo percurso metodológico ou pela análise da tarefa presentes no texto.

O site mantém o foco em:

- História da Matemática como tendência metodológica;
- Raciocínio Matemático, seus tipos e processos;
- princípios de elaboração de tarefas;
- Produto Educacional para o 5º ano do Ensino Fundamental;
- tarefa **A multiplicação egípcia dos grãos**, que é a tarefa descrita e analisada nesta versão da dissertação.

A seção “Aula em três fases” permanece excluída.

## Arquivos

- `index.html` — página inicial;
- `apresentacao.html` — questão, objetivo e composição do Produto Educacional;
- `historia.html` — referencial de História da Matemática;
- `raciocinio.html` — conceituação, tipos e processos de RM;
- `tarefas.html` — tarefa descrita e analisada na versão da dissertação;
- `saiba-mais.html` — organização dos autores do próprio referencial da dissertação;
- `referencias.html` — referências presentes na dissertação;
- `style.css` — estilos;
- `script.js` — interações visuais;
- `imagens/` — elementos visuais em SVG.

## Publicação no GitHub Pages

Substitua os arquivos do repositório pelos desta pasta, mantenha a pasta `imagens` e exclua qualquer arquivo antigo relacionado a “aula em três fases”.


## Correção dos links no GitHub Pages

Esta versão foi preparada especificamente para o endereço `https://vanessamedeirosss.github.io/Mestrado/`. Os links internos usam o prefixo `/Mestrado/`, evitando que **Saiba mais** e **Referências** quebrem por causa do caminho relativo.

É indispensável manter `referencias.html` e `saiba-mais.html` na raiz do repositório, junto com `index.html`. Também foram incluídas pastas de compatibilidade `referencias/` e `saiba-mais/` com redirecionamento.

```

## `apresentacao.html`
```html
<!DOCTYPE html>

<html lang="pt-BR">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<meta content="Apresentação do Produto Educacional e de sua fundamentação na dissertação." name="description"/>
<title>Apresentação | HM + RM</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"/>
<link href="/Mestrado/style.css" rel="stylesheet"/>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark site-nav sticky-top">
<div class="container">
<a class="navbar-brand d-flex align-items-center" href="/Mestrado/index.html"><span class="brand-mark"><i class="fa-solid fa-square-root-variable"></i></span>HM + RM</a>
<button aria-label="Abrir menu" class="navbar-toggler" data-bs-target="#menu" data-bs-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav ms-auto align-items-lg-center">
<li class="nav-item"><a class="nav-link" href="/Mestrado/index.html">Início</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/apresentacao.html">Apresentação</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/historia.html">História da Matemática</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/raciocinio.html">Raciocínio Matemático</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/tarefas.html">Tarefa</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/saiba-mais.html">Aprofundamento</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/referencias.html">Referências</a></li>
</ul>
</div>
</div>
</nav>
<header class="page-hero"><div class="container reveal"><span class="eyebrow"><i class="fa-solid fa-book-open-reader"></i> Apresentação</span><h1 class="display-4 mt-3">Uma proposta de ensino que articula História da Matemática e Raciocínio Matemático</h1><p class="mt-3 mb-0">O Produto Educacional é decorrente de uma pesquisa voltada ao 5º ano do Ensino Fundamental e toma a História da Matemática como tendência metodológica para investigar possibilidades de desenvolvimento do Raciocínio Matemático.</p></div></header>
<main>
<section class="section"><div class="container"><div class="row g-5 align-items-center">
<div class="col-lg-7 reveal"><div class="kicker">Questão de investigação</div><h2 class="section-title">Como a História da Matemática pode contribuir para o desenvolvimento do Raciocínio Matemático no Ensino Fundamental I?</h2><p>Essa questão orienta a pesquisa e a elaboração do Produto Educacional. O objetivo principal consiste em analisar o potencial didático da História da Matemática como tendência metodológica para o desenvolvimento do Raciocínio Matemático em estudantes do 5º ano do Ensino Fundamental I.</p><div class="notice mt-4"><strong>Foco da proposta:</strong> organizar tarefas com base em episódios e práticas da História da Matemática de modo a criar oportunidades para investigação, elaboração de estratégias, argumentação e produção de significados matemáticos.</div></div>
<div class="col-lg-5 reveal"><img alt="Articulação entre História da Matemática, tarefas e Raciocínio Matemático" src="/Mestrado/imagens/hm-rm-conexao.svg"/></div>
</div></div></section>
<section class="section section-soft"><div class="container">
<div class="text-center mb-5 reveal"><div class="kicker">Educação Matemática nos anos iniciais</div><h2 class="section-title">Aprender Matemática envolve mais do que reproduzir procedimentos</h2><p class="section-subtitle mx-auto">O referencial da dissertação defende práticas que favoreçam raciocinar, representar, comunicar e argumentar matematicamente, considerando os conhecimentos prévios dos estudantes e sua participação ativa na construção de relações e significados.</p></div>
<div class="row g-4"><div class="col-md-6 col-lg-3 reveal"><div class="feature-card"><span class="icon-orb gold"><i class="fa-solid fa-lightbulb"></i></span><h3 class="h5">Investigar</h3><p class="mb-0">Explorar situações e estabelecer relações em vez de limitar a aprendizagem à repetição de procedimentos.</p></div></div><div class="col-md-6 col-lg-3 reveal"><div class="feature-card"><span class="icon-orb teal"><i class="fa-solid fa-comments"></i></span><h3 class="h5">Comunicar</h3><p class="mb-0">Explicitar ideias, procedimentos e relações construídas durante a atividade matemática.</p></div></div><div class="col-md-6 col-lg-3 reveal"><div class="feature-card"><span class="icon-orb blue"><i class="fa-solid fa-code-branch"></i></span><h3 class="h5">Comparar estratégias</h3><p class="mb-0">Confrontar diferentes formas de resolução e reconhecer relações entre procedimentos.</p></div></div><div class="col-md-6 col-lg-3 reveal"><div class="feature-card"><span class="icon-orb rose"><i class="fa-solid fa-scale-balanced"></i></span><h3 class="h5">Justificar</h3><p class="mb-0">Apresentar razões que sustentem as afirmações e conclusões produzidas.</p></div></div></div>
</div></section>
<section class="section"><div class="container"><div class="row g-5">
<div class="col-lg-5 reveal"><div class="kicker">Composição do Produto Educacional</div><h2 class="section-title">Um guia didático estruturado para o 5º ano</h2><p>Segundo a dissertação, o Produto Educacional é constituído por uma sequência didática formada por tarefas voltadas ao desenvolvimento do RM com base na HM.</p></div>
<div class="col-lg-7 reveal"><div class="timeline"><div class="timeline-item"><h3 class="h5">Contexto histórico em História em Quadrinhos</h3><p class="mb-0">O episódio histórico é apresentado como parte da tarefa e articulado ao conhecimento matemático em estudo.</p></div><div class="timeline-item"><h3 class="h5">Objetivos de aprendizagem</h3><p class="mb-0">Cada tarefa explicita as aprendizagens matemáticas que orientam sua organização.</p></div><div class="timeline-item"><h3 class="h5">Orientações e possíveis encaminhamentos</h3><p class="mb-0">O material reúne elementos para apoiar o desenvolvimento das tarefas em sala de aula.</p></div><div class="timeline-item"><h3 class="h5">Relações com o Raciocínio Matemático</h3><p class="mb-0">As tarefas são analisadas em relação aos tipos e processos de RM que podem ser mobilizados.</p></div></div></div>
</div></div></section>
</main>
<footer class="site-footer">
<div class="container">
<div class="row g-4">
<div class="col-lg-7"><div class="footer-title">Desenvolvimento do Raciocínio Matemático no Ensino Fundamental I mediado pela História da Matemática</div><p class="mt-2 mb-0">Produto Educacional vinculado ao PPGEN/UNICENTRO.</p></div>
<div class="col-lg-5 text-lg-end"><p class="mb-1">Vanessa Medeiros • <span id="ano"></span></p><a href="/Mestrado/referencias.html">Referências da dissertação</a></div>
</div>
</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/Mestrado/script.js"></script>
</body>
</html>

```

## `historia.html`
```html
<!DOCTYPE html>

<html lang="pt-BR">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<meta content="História da Matemática como tendência metodológica, conforme o referencial teórico da dissertação." name="description"/>
<title>História da Matemática | HM + RM</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"/>
<link href="/Mestrado/style.css" rel="stylesheet"/>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark site-nav sticky-top">
<div class="container">
<a class="navbar-brand d-flex align-items-center" href="/Mestrado/index.html"><span class="brand-mark"><i class="fa-solid fa-square-root-variable"></i></span>HM + RM</a>
<button aria-label="Abrir menu" class="navbar-toggler" data-bs-target="#menu" data-bs-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav ms-auto align-items-lg-center">
<li class="nav-item"><a class="nav-link" href="/Mestrado/index.html">Início</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/apresentacao.html">Apresentação</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/historia.html">História da Matemática</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/raciocinio.html">Raciocínio Matemático</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/tarefas.html">Tarefa</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/saiba-mais.html">Aprofundamento</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/referencias.html">Referências</a></li>
</ul>
</div>
</div>
</nav>
<header class="page-hero"><div class="container reveal"><span class="eyebrow"><i class="fa-solid fa-landmark"></i> História da Matemática</span><h1 class="display-4 mt-3">A História da Matemática como tendência metodológica de ensino</h1><p class="mt-3 mb-0">Na dissertação, a HM é compreendida como uma possibilidade de reorganizar o ensino a partir de conhecimentos historicamente produzidos, articulando contexto histórico, atividade matemática e construção de significados.</p></div></header>
<main>
<section class="section"><div class="container"><div class="row g-5 align-items-center">
<div class="col-lg-7 reveal"><div class="kicker">Perspectiva adotada</div><h2 class="section-title">Da informação histórica à problematização matemática</h2><p>Miguel (1993) destaca que o valor da história não está apenas na reconstrução cronológica dos conceitos, mas na compreensão dos processos que conduziram à sua produção. Nessa perspectiva, a Matemática pode ser compreendida como um conhecimento construído em meio a problemas, debates, reformulações e validações.</p><p>Miguel e Miorim (2011) alertam que notas históricas, biografias e curiosidades, quando desarticuladas dos objetivos matemáticos, não garantem a construção de significados. O potencial pedagógico da HM depende de sua incorporação às atividades e das oportunidades de reflexão, investigação e discussão que essas atividades proporcionam.</p></div>
<div class="col-lg-5 reveal"><div class="quote-panel"><p>A História da Matemática deixa de ocupar um papel meramente ilustrativo quando passa a integrar a própria organização das tarefas e dos objetivos de aprendizagem.</p></div></div>
</div></div></section>
<section class="section section-soft"><div class="container"><div class="row g-4">
<div class="col-lg-4 reveal"><div class="feature-card"><span class="icon-orb gold"><i class="fa-solid fa-people-group"></i></span><h3>Produção humana e cultural</h3><p>D’Ambrosio (1999) compreende a Matemática como produção humana presente em diferentes civilizações, relacionada a formas de agir, explicar, organizar e interpretar o mundo.</p></div></div>
<div class="col-lg-4 reveal"><div class="feature-card"><span class="icon-orb teal"><i class="fa-solid fa-arrows-rotate"></i></span><h3>Reinvenção didática</h3><p>Mendes (2017) propõe reorganizar pedagogicamente conhecimentos produzidos historicamente, transformando problemas e episódios do passado em situações de aprendizagem coerentes com os objetivos de ensino.</p></div></div>
<div class="col-lg-4 reveal"><div class="feature-card"><span class="icon-orb blue"><i class="fa-solid fa-magnifying-glass"></i></span><h3>Investigação</h3><p>Fossa (2008) defende atividades construídas à luz da história que aproximem o estudante da atividade matemática de investigação, formulação de hipóteses, comparação de procedimentos e justificação de estratégias.</p></div></div>
</div></div></section>
<section class="section"><div class="container"><div class="row g-5">
<div class="col-lg-5 reveal"><div class="kicker">Planejamento didático</div><h2 class="section-title">O episódio histórico precisa estar articulado ao conceito matemático</h2><p>Chaquiam (2017; 2023) destaca que a utilização da HM exige planejamento e objetivos claramente definidos. A escolha de documentos, instrumentos, narrativas ou problemas históricos deve considerar sua contribuição para a aprendizagem do conceito matemático que se pretende desenvolver.</p></div>
<div class="col-lg-7 reveal"><div class="timeline"><div class="timeline-item"><h3 class="h5">Selecionar um contexto historicamente relevante</h3><p class="mb-0">O contexto não constitui um fim em si mesmo, mas um meio para favorecer a aprendizagem matemática.</p></div><div class="timeline-item"><h3 class="h5">Articular contexto e objetivo matemático</h3><p class="mb-0">Os elementos históricos devem estar relacionados aos conceitos e relações matemáticas que a tarefa pretende mobilizar.</p></div><div class="timeline-item"><h3 class="h5">Transformar o episódio em situação de aprendizagem</h3><p class="mb-0">A reorganização didática deve possibilitar investigação, comparação de estratégias, análise de procedimentos e construção de argumentos.</p></div></div></div>
</div></div></section>
<section class="section section-dark"><div class="container"><div class="row g-5 align-items-center">
<div class="col-lg-6 reveal"><div class="kicker" style="color:var(--gold-2)">Fontes históricas</div><h2 class="section-title">Documentos e registros podem ampliar a investigação</h2><p class="section-subtitle">Saito (2015) destaca que manuscritos, tratados, instrumentos e outros registros históricos podem constituir recursos para o ensino quando utilizados criticamente e adequadamente contextualizados, permitindo compreender diferentes formas de representação, resolução de problemas e organização do pensamento matemático.</p></div>
<div class="col-lg-6 reveal"><img alt="Representação de um registro histórico relacionado à matemática egípcia" src="/Mestrado/imagens/papiro-egipcio.svg"/></div>
</div></div></section>
<section class="section"><div class="container"><div class="row g-4 align-items-center">
<div class="col-lg-7 reveal"><div class="kicker">Síntese teórica</div><h2 class="section-title">A HM ultrapassa a função de contextualizar ou despertar interesse</h2><p>Na síntese construída na dissertação, diferentes autores convergem ao compreender a História da Matemática como uma tendência metodológica que pode contribuir para a construção de significados, para a compreensão da Matemática como produção humana e para a organização de ambientes investigativos que valorizem a participação ativa dos estudantes.</p></div>
<div class="col-lg-5 reveal"><div class="notice"><strong>Na pesquisa:</strong> a HM não é ensinada como fim em si mesma. Os episódios históricos são reorganizados didaticamente para compor tarefas nas quais os estudantes possam investigar, levantar hipóteses, comparar estratégias, justificar procedimentos e construir significados.</div></div>
</div></div></section>
</main>
<footer class="site-footer">
<div class="container">
<div class="row g-4">
<div class="col-lg-7"><div class="footer-title">Desenvolvimento do Raciocínio Matemático no Ensino Fundamental I mediado pela História da Matemática</div><p class="mt-2 mb-0">Produto Educacional vinculado ao PPGEN/UNICENTRO.</p></div>
<div class="col-lg-5 text-lg-end"><p class="mb-1">Vanessa Medeiros • <span id="ano"></span></p><a href="/Mestrado/referencias.html">Referências da dissertação</a></div>
</div>
</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/Mestrado/script.js"></script>
</body>
</html>

```

## `imagens/china-medidas.svg`
```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 520 260" role="img" aria-labelledby="t d">
  <title id="t">Medidas chinesas</title><desc id="d">Tecidos, régua estilizada e comparação de medidas.</desc>
  <rect width="520" height="260" rx="28" fill="#f9eee9"/>
  <path d="M95 75 C150 40 210 50 250 90 S355 145 425 95 V205 H95 Z" fill="#d78878" opacity=".55"/>
  <path d="M110 86 C165 55 212 72 260 106 S350 145 410 104" fill="none" stroke="#a85750" stroke-width="7"/>
  <rect x="95" y="200" width="330" height="24" rx="8" fill="#f2c66d" stroke="#9a6614" stroke-width="2"/>
  <g stroke="#9a6614" stroke-width="2"><path d="M125 200v16M160 200v11M195 200v16M230 200v11M265 200v16M300 200v11M335 200v16M370 200v11M405 200v16"/></g>
  <text x="112" y="52" font-family="Arial" font-size="18" fill="#1f2a44">medir • comparar • construir relações</text>
</svg>

```

## `imagens/grecia.svg`
```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 520 260" role="img" aria-labelledby="t d">
  <title id="t">Grécia e relações matemáticas</title><desc id="d">Colunas gregas e formas geométricas.</desc>
  <rect width="520" height="260" rx="28" fill="#eef3f7"/>
  <path d="M95 195 H425 M120 85 H400 M140 55 H380" stroke="#315c8c" stroke-width="12" stroke-linecap="round"/>
  <g fill="#dbe5ef" stroke="#315c8c" stroke-width="4"><rect x="140" y="90" width="44" height="100" rx="6"/><rect x="238" y="90" width="44" height="100" rx="6"/><rect x="336" y="90" width="44" height="100" rx="6"/></g>
  <circle cx="75" cy="65" r="28" fill="#f2c66d" opacity=".8"/>
  <text x="55" y="230" font-family="Arial" font-size="17" fill="#1f2a44">comparar • argumentar • justificar</text>
</svg>

```

## `imagens/hero-hm-rm.svg`
```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 560" role="img" aria-labelledby="title desc">
  <title id="title">História da Matemática conectada ao Raciocínio Matemático</title>
  <desc id="desc">Ilustração com papiro, pirâmide, símbolos matemáticos e trilha de raciocínio.</desc>
  <defs>
    <linearGradient id="paper" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fff3d6"/><stop offset="1" stop-color="#e8c77a"/></linearGradient>
    <linearGradient id="teal" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#dcefed"/><stop offset="1" stop-color="#7ab4ae"/></linearGradient>
  </defs>
  <rect x="20" y="30" width="720" height="500" rx="40" fill="#fffdf8" stroke="#1f2a44" stroke-opacity=".08"/>
  <circle cx="616" cy="112" r="62" fill="#f2c66d" opacity=".55"/>
  <path d="M490 390 L610 190 L730 390 Z" fill="#d79b2f" opacity=".8"/>
  <path d="M520 390 L610 240 L700 390 Z" fill="#f0c46c"/>
  <rect x="96" y="112" width="350" height="310" rx="22" fill="url(#paper)" stroke="#8f6a28" stroke-width="3"/>
  <path d="M115 158 C180 130 250 172 330 142 S410 150 425 136" fill="none" stroke="#8f6a28" stroke-width="4" opacity=".55"/>
  <path d="M125 210 H410 M125 250 H355 M125 290 H390" stroke="#8f6a28" stroke-width="4" opacity=".45" stroke-linecap="round"/>
  <g transform="translate(145 320)">
    <rect width="240" height="72" rx="18" fill="#1f2a44"/>
    <text x="22" y="31" font-family="Arial" font-size="16" fill="#fff">observar → conjecturar</text>
    <text x="22" y="55" font-family="Arial" font-size="16" fill="#f2c66d">generalizar → justificar</text>
  </g>
  <g fill="url(#teal)" stroke="#2f7a77" stroke-width="2">
    <circle cx="500" cy="105" r="34"/><circle cx="545" cy="150" r="28"/><circle cx="494" cy="178" r="24"/>
  </g>
  <g font-family="Georgia" font-weight="700" fill="#1f2a44">
    <text x="488" y="116" font-size="28">×</text><text x="535" y="160" font-size="24">∑</text><text x="486" y="187" font-size="20">?</text>
  </g>
  <path d="M424 448 C500 490 590 495 680 450" fill="none" stroke="#2f7a77" stroke-width="10" stroke-linecap="round" opacity=".75"/>
  <circle cx="436" cy="451" r="12" fill="#d79b2f"/><circle cx="678" cy="449" r="12" fill="#1f2a44"/>
  <text x="500" y="492" font-family="Arial" font-size="18" fill="#1f2a44">História → investigação → raciocínio</text>
</svg>

```

## `imagens/hm-rm-conexao.svg`
```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 300" role="img" aria-labelledby="t d">
  <title id="t">Conexão entre História da Matemática e Raciocínio Matemático</title><desc id="d">Fluxo de um episódio histórico para uma tarefa investigativa e para processos de raciocínio.</desc>
  <rect width="760" height="300" rx="28" fill="#fffdf8"/>
  <g font-family="Arial" text-anchor="middle">
    <rect x="30" y="85" width="190" height="130" rx="24" fill="#faedcf" stroke="#d79b2f" stroke-width="3"/>
    <text x="125" y="130" font-size="20" font-weight="700" fill="#1f2a44">Episódio histórico</text>
    <text x="125" y="162" font-size="15" fill="#1f2a44">problema • prática • fonte</text>
    <rect x="285" y="85" width="190" height="130" rx="24" fill="#e3ebf4" stroke="#315c8c" stroke-width="3"/>
    <text x="380" y="130" font-size="20" font-weight="700" fill="#1f2a44">Tarefa exploratória</text>
    <text x="380" y="162" font-size="15" fill="#1f2a44">estratégias • discussão</text>
    <rect x="540" y="85" width="190" height="130" rx="24" fill="#dcefed" stroke="#2f7a77" stroke-width="3"/>
    <text x="635" y="130" font-size="20" font-weight="700" fill="#1f2a44">Raciocínio Matemático</text>
    <text x="635" y="162" font-size="15" fill="#1f2a44">conjecturar • generalizar</text>
    <text x="635" y="184" font-size="15" fill="#1f2a44">justificar • validar</text>
    <text x="252" y="155" font-size="34" fill="#d79b2f">→</text>
    <text x="507" y="155" font-size="34" fill="#2f7a77">→</text>
  </g>
</svg>

```

## `imagens/papiro-egipcio.svg`
```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 520 260" role="img" aria-labelledby="t d">
  <title id="t">Papiro e dobramentos</title><desc id="d">Representação visual de um papiro com a sequência 1, 2, 4 e 8.</desc>
  <defs><linearGradient id="g" x1="0" x2="1"><stop stop-color="#fff0c7"/><stop offset="1" stop-color="#e4c06d"/></linearGradient></defs>
  <rect x="48" y="40" width="424" height="180" rx="22" fill="url(#g)" stroke="#9b7023" stroke-width="3"/>
  <circle cx="48" cy="80" r="26" fill="#f6d88f" stroke="#9b7023" stroke-width="3"/><circle cx="472" cy="180" r="26" fill="#f6d88f" stroke="#9b7023" stroke-width="3"/>
  <text x="95" y="92" font-family="Georgia" font-size="30" fill="#1f2a44">1 → 2 → 4 → 8</text>
  <text x="95" y="136" font-family="Arial" font-size="18" fill="#6d5526">dobrar • combinar • justificar</text>
  <path d="M95 166 H395" stroke="#9b7023" stroke-width="4" stroke-linecap="round" opacity=".45"/>
</svg>

```

## `index.html`
```html
<!DOCTYPE html>

<html lang="pt-BR">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<meta content="Produto Educacional fundamentado na dissertação sobre História da Matemática e Raciocínio Matemático." name="description"/>
<title>Início | HM + RM</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"/>
<link href="/Mestrado/style.css" rel="stylesheet"/>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark site-nav sticky-top">
<div class="container">
<a class="navbar-brand d-flex align-items-center" href="/Mestrado/index.html"><span class="brand-mark"><i class="fa-solid fa-square-root-variable"></i></span>HM + RM</a>
<button aria-label="Abrir menu" class="navbar-toggler" data-bs-target="#menu" data-bs-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav ms-auto align-items-lg-center">
<li class="nav-item"><a class="nav-link" href="/Mestrado/index.html">Início</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/apresentacao.html">Apresentação</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/historia.html">História da Matemática</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/raciocinio.html">Raciocínio Matemático</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/tarefas.html">Tarefa</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/saiba-mais.html">Aprofundamento</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/referencias.html">Referências</a></li>
</ul>
</div>
</div>
</nav>
<header class="hero">
<div class="container">
<div class="row align-items-center g-5">
<div class="col-lg-7 reveal">
<span class="eyebrow"><i class="fa-solid fa-scroll"></i> Produto Educacional • 5º ano do Ensino Fundamental</span>
<h1 class="mt-3">História da Matemática como tendência metodológica para o desenvolvimento do Raciocínio Matemático</h1>
<p class="lead mt-4">Este ambiente apresenta os fundamentos e a proposta didática da pesquisa, na qual episódios da História da Matemática são reorganizados em tarefas que favorecem a investigação, a comparação de estratégias, a construção de significados e a mobilização de processos de Raciocínio Matemático.</p>
<div class="d-flex flex-wrap gap-3 mt-4">
<a class="btn btn-primary-custom" href="/Mestrado/historia.html"><i class="fa-solid fa-landmark me-2"></i>História da Matemática</a>
<a class="btn btn-outline-custom" href="/Mestrado/raciocinio.html"><i class="fa-solid fa-brain me-2"></i>Raciocínio Matemático</a>
</div>
</div>
<div class="col-lg-5 reveal"><div class="hero-visual"><img alt="Ilustração relacionando História da Matemática e Raciocínio Matemático" src="/Mestrado/imagens/hero-hm-rm.svg"/></div></div>
</div>
</div>
</header>
<main>
<section class="section" id="conexao"><div class="container">
<div class="row align-items-end mb-4 g-4 reveal"><div class="col-lg-9">
<div class="kicker">Fundamento da proposta</div>
<h2 class="section-title">A História da Matemática integra a organização do ensino quando é articulada aos objetivos matemáticos.</h2>
<p class="section-subtitle">Na perspectiva adotada na dissertação, a HM não se reduz à apresentação de datas, biografias ou curiosidades. Seu potencial pedagógico está relacionado à reorganização de conhecimentos historicamente produzidos em situações de aprendizagem que possibilitem aos estudantes investigar problemas, comparar procedimentos e construir significados matemáticos (Miguel &amp; Miorim, 2011; Mendes, 2017).</p>
</div></div>
<div class="bridge-card reveal"><img alt="Relação entre episódio histórico, tarefa matemática e Raciocínio Matemático" src="/Mestrado/imagens/hm-rm-conexao.svg"/></div>
</div></section>
<section class="section section-soft"><div class="container">
<div class="text-center mb-5 reveal"><div class="kicker">Raciocínio Matemático</div><h2 class="section-title">Produzir novas conclusões a partir de informações conhecidas, de forma fundamentada</h2><p class="section-subtitle mx-auto">O RM é compreendido como um processo que envolve inferência, comunicação, argumentação, validação e produção de significados. Na dissertação, sua análise considera tipos de raciocínio e processos mobilizados durante a atividade matemática.</p></div>
<div class="row g-4">
<div class="col-lg-4 reveal"><div class="feature-card"><span class="icon-orb gold"><i class="fa-solid fa-lightbulb"></i></span><h3>Raciocínio abdutivo</h3><p>Relaciona-se à formulação de hipóteses explicativas e à elaboração de possíveis estratégias diante de uma situação matemática.</p></div></div>
<div class="col-lg-4 reveal"><div class="feature-card"><span class="icon-orb teal"><i class="fa-solid fa-chart-line"></i></span><h3>Raciocínio indutivo</h3><p>Envolve inferir uma regra ou relação mais geral a partir da observação de regularidades em casos particulares.</p></div></div>
<div class="col-lg-4 reveal"><div class="feature-card"><span class="icon-orb rose"><i class="fa-solid fa-scale-balanced"></i></span><h3>Raciocínio dedutivo</h3><p>Relaciona-se à obtenção e validação de conclusões a partir de afirmações, propriedades e regras de inferência assumidas como válidas.</p></div></div>
</div>
</div></section>
<section class="section"><div class="container">
<div class="row g-4 align-items-center"><div class="col-lg-5 reveal"><div class="kicker">Processos do RM</div><h2 class="section-title">Conjecturar, generalizar, justificar e validar</h2><p>Conjecturar envolve formular hipóteses ou estratégias; generalizar consiste em reconhecer relações que podem ser ampliadas; justificar implica apresentar razões que sustentem uma afirmação; e validar corresponde ao exame da consistência das estratégias e conclusões produzidas (Ponte, Quaresma &amp; Mata-Pereira, 2020; Araman &amp; Serrazina, 2020).</p></div>
<div class="col-lg-7 reveal"><div class="concept-flow"><div class="flow-step"><span class="num">1</span>Conjecturar<small>formular hipóteses e estratégias</small></div><div class="flow-step"><span class="num">2</span>Generalizar<small>reconhecer padrões e ampliar relações</small></div><div class="flow-step"><span class="num">3</span>Justificar<small>apresentar razões matemáticas</small></div><div class="flow-step"><span class="num">4</span>Validar<small>examinar a consistência das conclusões</small></div></div></div></div>
</div></section>
<section class="section section-dark"><div class="container"><div class="row g-4 align-items-center">
<div class="col-lg-7 reveal"><div class="kicker" style="color:var(--gold-2)">Produto Educacional</div><h2 class="section-title">Uma sequência didática organizada para o trabalho no 5º ano</h2><p class="section-subtitle">O produto reúne tarefas com contexto histórico apresentado em História em Quadrinhos, objetivos de aprendizagem, orientações para o professor, possíveis encaminhamentos e relações com o desenvolvimento do Raciocínio Matemático.</p><a class="btn btn-light rounded-pill fw-bold px-4 py-2 mt-2" href="/Mestrado/tarefas.html">Conhecer a tarefa analisada</a></div>
<div class="col-lg-5 reveal"><img alt="Representação visual da tarefa sobre multiplicação egípcia" src="/Mestrado/imagens/papiro-egipcio.svg"/></div>
</div></div></section>
</main>
<footer class="site-footer">
<div class="container">
<div class="row g-4">
<div class="col-lg-7"><div class="footer-title">Desenvolvimento do Raciocínio Matemático no Ensino Fundamental I mediado pela História da Matemática</div><p class="mt-2 mb-0">Produto Educacional vinculado ao PPGEN/UNICENTRO.</p></div>
<div class="col-lg-5 text-lg-end"><p class="mb-1">Vanessa Medeiros • <span id="ano"></span></p><a href="/Mestrado/referencias.html">Referências da dissertação</a></div>
</div>
</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/Mestrado/script.js"></script>
</body>
</html>

```

## `raciocinio.html`
```html
<!DOCTYPE html>

<html lang="pt-BR">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<meta content="Conceituação, tipos e processos de Raciocínio Matemático conforme o referencial da dissertação." name="description"/>
<title>Raciocínio Matemático | HM + RM</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"/>
<link href="/Mestrado/style.css" rel="stylesheet"/>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark site-nav sticky-top">
<div class="container">
<a class="navbar-brand d-flex align-items-center" href="/Mestrado/index.html"><span class="brand-mark"><i class="fa-solid fa-square-root-variable"></i></span>HM + RM</a>
<button aria-label="Abrir menu" class="navbar-toggler" data-bs-target="#menu" data-bs-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav ms-auto align-items-lg-center">
<li class="nav-item"><a class="nav-link" href="/Mestrado/index.html">Início</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/apresentacao.html">Apresentação</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/historia.html">História da Matemática</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/raciocinio.html">Raciocínio Matemático</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/tarefas.html">Tarefa</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/saiba-mais.html">Aprofundamento</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/referencias.html">Referências</a></li>
</ul>
</div>
</div>
</nav>
<header class="page-hero"><div class="container reveal"><span class="eyebrow"><i class="fa-solid fa-brain"></i> Raciocínio Matemático</span><h1 class="display-4 mt-3">Raciocinar matematicamente envolve produzir novas conclusões de forma fundamentada</h1><p class="mt-3 mb-0">O referencial da dissertação compreende o RM como um processo complexo que articula inferência, comunicação, argumentação, validação e produção de significados.</p></div></header>
<main>
<section class="section"><div class="container"><div class="row g-5 align-items-center">
<div class="col-lg-7 reveal"><div class="kicker">Conceituação</div><h2 class="section-title">Do conhecimento já disponível à produção de novas conclusões</h2><p>Araman e Serrazina (2020) destacam, entre diferentes concepções de RM, a ideia comum de produção de novo conhecimento a partir de conhecimentos já existentes. Stylianides (2009) associa o raciocínio a um processo de inferência que utiliza informação matemática conhecida para obter novo conhecimento, enquanto Mata-Pereira e Ponte (2018) enfatizam que essas novas conclusões devem ser obtidas de modo justificado.</p><p>Ponte, Quaresma e Mata-Pereira (2020) diferenciam raciocinar de pensar: raciocinar envolve realizar inferências de forma fundamentada. Assim, as conclusões precisam estar articuladas a razões, relações e justificações matematicamente sustentadas.</p></div>
<div class="col-lg-5 reveal"><div class="quote-panel"><p>O RM não se reduz à reprodução de regras ou procedimentos: envolve mobilizar conhecimentos prévios, estabelecer relações e sustentar novas conclusões por meio de argumentos e justificações.</p></div></div>
</div></div></section>
<section class="section section-soft"><div class="container">
<div class="text-center mb-5 reveal"><div class="kicker">Aspecto estrutural</div><h2 class="section-title">Tipos de Raciocínio Matemático</h2><p class="section-subtitle mx-auto">A dissertação destaca três tipos: dedutivo, indutivo e abdutivo. Eles desempenham funções distintas e complementares na produção e validação do conhecimento matemático.</p></div>
<div class="rm-grid">
<div class="rm-card reveal"><span class="icon-orb rose"><i class="fa-solid fa-scale-balanced"></i></span><strong>Raciocínio dedutivo</strong><p>Parte de afirmações assumidas como verdadeiras e de regras de inferência para obter novas afirmações. Seu papel está especialmente relacionado à justificação e à validação.</p></div>
<div class="rm-card reveal"><span class="icon-orb teal"><i class="fa-solid fa-chart-line"></i></span><strong>Raciocínio indutivo</strong><p>Envolve inferir uma regra a partir da observação de regularidades em casos particulares. Contribui para a formulação de generalizações.</p></div>
<div class="rm-card reveal"><span class="icon-orb gold"><i class="fa-solid fa-lightbulb"></i></span><strong>Raciocínio abdutivo</strong><p>Corresponde à formulação de uma hipótese explicativa diante de uma situação, fato ou resultado que demanda interpretação. Está associado à produção de conjecturas.</p></div>
</div>
</div></section>
<section class="section"><div class="container">
<div class="mb-4 reveal"><div class="kicker">Aspecto processual</div><h2 class="section-title">Processos de Raciocínio Matemático</h2><p>Entre os processos discutidos na dissertação, destacam-se conjecturar, generalizar, justificar e validar. Esses processos se articulam aos tipos de raciocínio durante a atividade matemática.</p></div>
<div class="process-table reveal"><div class="process-row head"><div class="process-name">Processo</div><div>Caracterização na dissertação</div><div>Relação teórica destacada</div></div><div class="process-row"><div class="process-name">Conjecturar</div><div>Formular hipóteses, identificar possíveis soluções ou elaborar estratégias diante de uma situação matemática.</div><div>Processo central do raciocínio abdutivo.</div></div><div class="process-row"><div class="process-name">Generalizar</div><div>Reconhecer padrões, propriedades comuns ou relações que podem ser ampliadas para um conjunto mais alargado de objetos.</div><div>Processo-chave dos raciocínios indutivo e abdutivo.</div></div><div class="process-row"><div class="process-name">Justificar</div><div>Apresentar razões que sustentem uma afirmação, com base em definições, propriedades, princípios gerais, representações ou combinações desses elementos.</div><div>Processo essencial do raciocínio dedutivo.</div></div><div class="process-row"><div class="process-name">Validar</div><div>Examinar a consistência das afirmações, estratégias e conclusões produzidas.</div><div>Relaciona-se ao exame e à sustentação das ideias matemáticas.</div></div></div>
</div></section>
<section class="section section-dark"><div class="container"><div class="row g-5 align-items-start">
<div class="col-lg-5 reveal"><div class="kicker" style="color:var(--gold-2)">Promoção do RM</div><h2 class="section-title">As tarefas e as ações do professor são centrais</h2><p class="section-subtitle">Ponte (2014) destaca que a atividade matemática realizada pelos estudantes é desencadeada, em grande parte, pelas tarefas propostas. Mata-Pereira e Ponte (2018) acrescentam que a promoção do RM também depende das ações do professor durante a realização dessas tarefas.</p></div>
<div class="col-lg-7 reveal"><div class="timeline"><div class="timeline-item"><h3 class="h5 text-white">Variedade de estratégias</h3><p class="mb-0 text-white-50">O documento REASON recomenda questões que permitam diferentes estratégias de resolução.</p></div><div class="timeline-item"><h3 class="h5 text-white">Diferentes representações</h3><p class="mb-0 text-white-50">As tarefas podem envolver múltiplas formas de representar e comunicar as ideias matemáticas.</p></div><div class="timeline-item"><h3 class="h5 text-white">Reflexão sobre o raciocínio</h3><p class="mb-0 text-white-50">As questões devem incentivar os estudantes a refletir sobre os processos de raciocínio utilizados.</p></div><div class="timeline-item"><h3 class="h5 text-white">Generalização e justificação</h3><p class="mb-0 text-white-50">Os princípios específicos propõem observar semelhanças e diferenças, formular generalizações e solicitar justificações de diferentes naturezas.</p></div></div></div>
</div></div></section>
<section class="section"><div class="container"><div class="row g-4 align-items-center"><div class="col-lg-7 reveal"><div class="kicker">Síntese</div><h2 class="section-title">O RM articula dimensões conceitual, didática e formativa</h2><p>A dissertação sintetiza o RM em três dimensões articuladas: conceitual, relacionada à definição de seus tipos e processos; didática, referente às tarefas, interações e discussões que favorecem conjecturas, generalizações, justificações e validações; e formativa, ligada aos conhecimentos e ações docentes necessários para planejar, implementar e analisar situações de ensino voltadas ao raciocínio matemático.</p></div><div class="col-lg-5 reveal"><div class="notice"><strong>Consequência didática:</strong> o desenvolvimento do RM depende de tarefas matemáticas desafiadoras, de ambientes comunicativos e de ações docentes intencionais que favoreçam a explicitação e o confronto de ideias.</div></div></div></div></section>
</main>
<footer class="site-footer">
<div class="container">
<div class="row g-4">
<div class="col-lg-7"><div class="footer-title">Desenvolvimento do Raciocínio Matemático no Ensino Fundamental I mediado pela História da Matemática</div><p class="mt-2 mb-0">Produto Educacional vinculado ao PPGEN/UNICENTRO.</p></div>
<div class="col-lg-5 text-lg-end"><p class="mb-1">Vanessa Medeiros • <span id="ano"></span></p><a href="/Mestrado/referencias.html">Referências da dissertação</a></div>
</div>
</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/Mestrado/script.js"></script>
</body>
</html>

```

## `referencias/index.html`
```html
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta http-equiv="refresh" content="0; url=../referencias.html"><link rel="canonical" href="../referencias.html"><title>Redirecionando...</title></head><body><p>Redirecionando... <a href="../referencias.html">Clique aqui se não abrir automaticamente.</a></p></body></html>
```

## `referencias.html`
```html
<!DOCTYPE html>

<html lang="pt-BR">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<meta content="Referências presentes na dissertação e utilizadas para fundamentar o site." name="description"/>
<title>Referências | HM + RM</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"/>
<link href="/Mestrado/style.css" rel="stylesheet"/>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark site-nav sticky-top">
<div class="container">
<a class="navbar-brand d-flex align-items-center" href="/Mestrado/index.html"><span class="brand-mark"><i class="fa-solid fa-square-root-variable"></i></span>HM + RM</a>
<button aria-label="Abrir menu" class="navbar-toggler" data-bs-target="#menu" data-bs-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav ms-auto align-items-lg-center">
<li class="nav-item"><a class="nav-link" href="/Mestrado/index.html">Início</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/apresentacao.html">Apresentação</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/historia.html">História da Matemática</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/raciocinio.html">Raciocínio Matemático</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/tarefas.html">Tarefa</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/saiba-mais.html">Aprofundamento</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/referencias.html">Referências</a></li>
</ul>
</div>
</div>
</nav>
<header class="page-hero"><div class="container reveal"><span class="eyebrow"><i class="fa-solid fa-quote-right"></i> Referências</span><h1 class="display-4 mt-3">Referências mobilizadas na dissertação</h1><p class="mt-3 mb-0">A seleção abaixo reúne obras citadas no referencial teórico e nas discussões relacionadas à História da Matemática, ao Raciocínio Matemático e às tarefas.</p></div></header>
<main><section class="section py-4"><div class="container"><div class="reference-jump d-flex flex-wrap gap-2 justify-content-center"><a class="btn btn-outline-primary" href="#hm">História da Matemática</a><a class="btn btn-outline-primary" href="#rm">Raciocínio Matemático</a><a class="btn btn-outline-primary" href="#ensino">Ensino, tarefas e currículo</a></div></div></section>
<section class="section" id="hm"><div class="container"><div class="row g-5"><div class="col-lg-4 reveal"><div class="kicker">História da Matemática</div><h2 class="section-title">Referências centrais</h2></div><div class="col-lg-8 reveal"><div class="reference-list">
<div class="reference-item"><strong>CHAQUIAM, M.</strong> <em>História da Matemática em Sala de Aula: proposta para integração aos conteúdos matemáticos.</em> São Paulo: Livraria da Física, 2015.</div>
<div class="reference-item"><strong>CHAQUIAM, M.</strong> <em>Ensaios temáticos: história e matemática em sala de aula.</em> 1. ed. Belém: SBEM/SBEM-PA, 2017.</div>
<div class="reference-item"><strong>CHAQUIAM, M.</strong> <em>História e matemática: contextos, textos e atividades.</em> São Paulo: Livraria da Física, 2023.</div>
<div class="reference-item"><strong>D’AMBROSIO, U.</strong> A história da matemática: questões historiográficas e políticas e reflexos na Educação Matemática. In: BICUDO, Maria Aparecida Viggiani (org.). <em>Pesquisa em educação matemática: concepções &amp; perspectivas.</em> São Paulo: Editora UNESP, 1999. p. 97-115.</div>
<div class="reference-item"><strong>FOSSA, J. A.</strong> <em>Matemática, história e compreensão.</em> Universidade Federal do Rio Grande do Norte, 2008.</div>
<div class="reference-item"><strong>MENDES, I. A.</strong> História para o ensino da matemática: uma reinvenção didática para a sala de aula. <em>Revista Cocar</em>, Belém, n. 3, edição especial, p. 145-166, 2017.</div>
<div class="reference-item"><strong>MIGUEL, A.</strong> <em>Três estudos sobre história e educação matemática.</em> 1993. Tese (Doutorado em Educação) – Faculdade de Educação, Universidade Estadual de Campinas, Campinas, 1993.</div>
<div class="reference-item"><strong>MIGUEL, A.; MIORIM, M. A.</strong> <em>História na educação matemática: propostas e desafios.</em> 2. ed. Belo Horizonte: Autêntica, 2011.</div>
<div class="reference-item"><strong>ROQUE, T.</strong> <em>História da matemática: uma visão crítica, desfazendo mitos e lendas.</em> Rio de Janeiro: Zahar, 2012.</div>
<div class="reference-item"><strong>ROQUE, T.</strong> Desmascarando a equação: a história no ensino de que matemática? <em>Revista Brasileira de História da Ciência</em>, Rio de Janeiro, v. 7, n. 2, p. 167-185, 2014.</div>
<div class="reference-item"><strong>SAITO, F.</strong> <em>História da matemática e suas (re)construções contextuais.</em> São Paulo: Editora Livraria da Física, 2015.</div>
<div class="reference-item"><strong>VIANNA, C. R.</strong> Usos didáticos para a História da Matemática. In: SEMINÁRIO NACIONAL DE HISTÓRIA DA MATEMÁTICA, 1., 1995, Recife. <em>Anais</em> [...]. Recife: SBHMat, 1998. p. 65-79.</div>
</div></div></div></div></section>
<section class="section section-soft" id="rm"><div class="container"><div class="row g-5"><div class="col-lg-4 reveal"><div class="kicker">Raciocínio Matemático</div><h2 class="section-title">Tipos, processos e promoção do RM</h2></div><div class="col-lg-8 reveal"><div class="reference-list">
<div class="reference-item"><strong>ARAMAN, E. M. O.; SERRAZINA, M. L.</strong> Processos de raciocínio matemático na resolução de tarefas exploratórias no 3º ano de escolaridade. <em>Revista Paranaense de Educação Matemática</em>, Campo Mourão, v. 9, n. 18, p. 118-136, 2020.</div>
<div class="reference-item"><strong>LANNIN, J.; ELLIS, A. B.; ELLIOT, R.</strong> <em>Developing essential understanding of mathematical reasoning for teaching mathematics in prekindergarten-grade 8.</em> Reston: National Council of Teachers of Mathematics, 2011.</div>
<div class="reference-item"><strong>MATA-PEREIRA, J.; PONTE, J. P.</strong> Promover o raciocínio matemático dos alunos: uma investigação baseada em design. <em>Bolema</em>, v. 32, n. 62, p. 781-801, 2018.</div>
<div class="reference-item"><strong>MORAIS, C.; SERRAZINA, L.; PONTE, J. P.</strong> Mathematical reasoning fostered by transformations of rational number representations. <em>Acta Scientiae</em>, v. 20, n. 4, p. 552-570, 2018.</div>
<div class="reference-item"><strong>OLIVEIRA, P.</strong> O raciocínio matemático à luz de uma epistemologia soft. <em>Educação e Matemática</em>, Lisboa, n. 100, p. 3-9, 2008.</div>
<div class="reference-item"><strong>PONTE, J. P.; MATA-PEREIRA, J.; HENRIQUES, A.</strong> O raciocínio matemático nos alunos do Ensino Básico e do Ensino Superior. <em>Práxis Educativa</em>, v. 7, n. 2, p. 355-377, 2012.</div>
<div class="reference-item"><strong>PONTE, J. P.; QUARESMA, M.; MATA-PEREIRA, J.</strong> Como desenvolver o raciocínio matemático na sala de aula? <em>Educação &amp; Matemática</em>, n. 156, p. 7-11, 2020.</div>
<div class="reference-item"><strong>REASON.</strong> <em>Princípios para elaboração de tarefas para promover o raciocínio matemático nos alunos.</em> [S. l.]: Projeto REASON, [s.d.].</div>
<div class="reference-item"><strong>RIVERA, F. D.; BECKER, J. R.</strong> Abduction–induction (generalization) processes of elementary majors on figural patterns in algebra. <em>The Journal of Mathematical Behavior</em>, v. 26, n. 2, p. 140-155, 2007.</div>
<div class="reference-item"><strong>STYLIANIDES, G.</strong> Reasoning-and-proving in school mathematics textbooks. <em>Mathematical Thinking and Learning</em>, v. 11, n. 4, p. 258-288, 2009.</div>
</div></div></div></div></section>
<section class="section" id="ensino"><div class="container"><div class="row g-5"><div class="col-lg-4 reveal"><div class="kicker">Ensino, tarefas e currículo</div><h2 class="section-title">Outras referências citadas</h2></div><div class="col-lg-8 reveal"><div class="reference-list">
<div class="reference-item"><strong>BRASIL.</strong> Ministério da Educação. <em>Base Nacional Comum Curricular.</em> Brasília: MEC, 2018.</div>
<div class="reference-item"><strong>CYRINO, M. C. C. T.; ESTEVAM, E. J. G.</strong> Tarefas matemáticas na formação de professores que ensinam Matemática. <em>Perspectivas da Educação Matemática</em>, Campo Grande, v. 16, n. 42, 2023.</div>
<div class="reference-item"><strong>PONTE, J. P.</strong> Tarefas no ensino e na aprendizagem da Matemática. <em>Práticas profissionais dos professores de Matemática.</em> Lisboa: Instituto de Educação da Universidade de Lisboa, 2014.</div>
<div class="reference-item"><strong>LORENZATO, S.</strong> <em>Para aprender matemática.</em> Campinas, SP: Autores Associados, 2006.</div>
<div class="reference-item"><strong>KAMII, C.</strong> <em>A criança e o número: Implicações educacionais da teoria de Piaget para a atuação com escolares de 4 a 6 anos.</em> 11. ed. Campinas, SP: Papirus, 1990.</div>
</div></div></div></div></section>
</main>
<footer class="site-footer">
<div class="container">
<div class="row g-4">
<div class="col-lg-7"><div class="footer-title">Desenvolvimento do Raciocínio Matemático no Ensino Fundamental I mediado pela História da Matemática</div><p class="mt-2 mb-0">Produto Educacional vinculado ao PPGEN/UNICENTRO.</p></div>
<div class="col-lg-5 text-lg-end"><p class="mb-1">Vanessa Medeiros • <span id="ano"></span></p><a href="/Mestrado/referencias.html">Referências da dissertação</a></div>
</div>
</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/Mestrado/script.js"></script>
</body>
</html>

```

## `saiba-mais/index.html`
```html
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta http-equiv="refresh" content="0; url=../saiba-mais.html"><link rel="canonical" href="../saiba-mais.html"><title>Redirecionando...</title></head><body><p>Redirecionando... <a href="../saiba-mais.html">Clique aqui se não abrir automaticamente.</a></p></body></html>
```

## `saiba-mais.html`
```html
<!DOCTYPE html>

<html lang="pt-BR">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<meta content="Aprofundamento teórico com autores presentes no referencial da dissertação." name="description"/>
<title>Aprofundamento | HM + RM</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"/>
<link href="/Mestrado/style.css" rel="stylesheet"/>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark site-nav sticky-top">
<div class="container">
<a class="navbar-brand d-flex align-items-center" href="/Mestrado/index.html"><span class="brand-mark"><i class="fa-solid fa-square-root-variable"></i></span>HM + RM</a>
<button aria-label="Abrir menu" class="navbar-toggler" data-bs-target="#menu" data-bs-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav ms-auto align-items-lg-center">
<li class="nav-item"><a class="nav-link" href="/Mestrado/index.html">Início</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/apresentacao.html">Apresentação</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/historia.html">História da Matemática</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/raciocinio.html">Raciocínio Matemático</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/tarefas.html">Tarefa</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/saiba-mais.html">Aprofundamento</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/referencias.html">Referências</a></li>
</ul>
</div>
</div>
</nav>
<header class="page-hero"><div class="container reveal"><span class="eyebrow"><i class="fa-solid fa-book-bookmark"></i> Aprofundamento teórico</span><h1 class="display-4 mt-3">Autores e ideias que sustentam a proposta</h1><p class="mt-3 mb-0">Esta página organiza, sem acrescentar novos referenciais, alguns dos autores mobilizados na dissertação para fundamentar a História da Matemática, o Raciocínio Matemático e a elaboração de tarefas.</p></div></header>
<main>
<section class="section"><div class="container"><div class="text-center mb-5 reveal"><div class="kicker">História da Matemática</div><h2 class="section-title">Eixos de leitura presentes no referencial</h2></div><div class="row g-4">
<div class="col-md-6 col-lg-4 reveal"><div class="resource-card"><span class="resource-type">Miguel; Miguel &amp; Miorim</span><h3>Historicidade e problematização</h3><p>Contribuem para compreender a HM para além da cronologia e das curiosidades, valorizando os processos de produção dos conceitos e sua articulação aos objetivos matemáticos.</p><a class="fw-bold" href="/Mestrado/referencias.html#hm" title="Abrir a seção correspondente nas Referências">Ver referências <i class="fa-solid fa-arrow-right ms-1"></i></a></div></div>
<div class="col-md-6 col-lg-4 reveal"><div class="resource-card"><span class="resource-type">Mendes</span><h3>História para o Ensino da Matemática</h3><p>Fundamenta a noção de reinvenção didática, entendida como reorganização pedagógica de conhecimentos historicamente produzidos em situações de aprendizagem.</p><a class="fw-bold" href="/Mestrado/referencias.html#hm" title="Abrir a seção correspondente nas Referências">Ver referência <i class="fa-solid fa-arrow-right ms-1"></i></a></div></div>
<div class="col-md-6 col-lg-4 reveal"><div class="resource-card"><span class="resource-type">Fossa; Chaquiam; Saito</span><h3>Investigação, planejamento e fontes históricas</h3><p>Esses autores sustentam o uso de problemas históricos, a necessidade de objetivos didáticos definidos e a exploração crítica de documentos, instrumentos e outros registros históricos.</p><a class="fw-bold" href="/Mestrado/referencias.html#hm" title="Abrir a seção correspondente nas Referências">Ver referências <i class="fa-solid fa-arrow-right ms-1"></i></a></div></div>
</div></div></section>
<section class="section section-soft"><div class="container"><div class="text-center mb-5 reveal"><div class="kicker">Raciocínio Matemático</div><h2 class="section-title">Conceitos que orientam a análise</h2></div><div class="row g-4">
<div class="col-md-6 col-lg-4 reveal"><div class="resource-card"><span class="resource-type">Ponte, Quaresma &amp; Mata-Pereira</span><h3>Tipos e processos de raciocínio</h3><p>Contribuem para distinguir raciocínio dedutivo, indutivo e abdutivo e para relacioná-los aos processos de conjecturar, generalizar e justificar.</p><a class="fw-bold" href="/Mestrado/referencias.html#rm" title="Abrir a seção correspondente nas Referências">Ver referência <i class="fa-solid fa-arrow-right ms-1"></i></a></div></div>
<div class="col-md-6 col-lg-4 reveal"><div class="resource-card"><span class="resource-type">Araman &amp; Serrazina</span><h3>Processos de RM nos anos iniciais</h3><p>Apresentam evidências de conjectura, generalização, validação e justificação em tarefas exploratórias realizadas por estudantes dos anos iniciais.</p><a class="fw-bold" href="/Mestrado/referencias.html#rm" title="Abrir a seção correspondente nas Referências">Ver referência <i class="fa-solid fa-arrow-right ms-1"></i></a></div></div>
<div class="col-md-6 col-lg-4 reveal"><div class="resource-card"><span class="resource-type">Mata-Pereira &amp; Ponte; REASON</span><h3>Tarefas e ações docentes</h3><p>Fundamentam a importância das tarefas, das ações do professor e de princípios de elaboração que favoreçam diferentes estratégias, representações, generalizações e justificações.</p><a class="fw-bold" href="/Mestrado/referencias.html#rm" title="Abrir a seção correspondente nas Referências">Ver referências <i class="fa-solid fa-arrow-right ms-1"></i></a></div></div>
</div></div></section>
<section class="section"><div class="container"><div class="row g-5 align-items-center"><div class="col-lg-7 reveal"><div class="kicker">Articulação central</div><h2 class="section-title">História da Matemática, tarefas e Raciocínio Matemático</h2><p>A articulação construída na dissertação parte da compreensão de que episódios históricos, quando reorganizados didaticamente e integrados aos objetivos de aprendizagem, podem compor tarefas que favoreçam exploração, discussão de estratégias, formulação de conjecturas, generalização, justificação e validação.</p></div><div class="col-lg-5 reveal"><img alt="Articulação entre História da Matemática, tarefa e Raciocínio Matemático" src="/Mestrado/imagens/hm-rm-conexao.svg"/></div></div></div></section>
</main>
<footer class="site-footer">
<div class="container">
<div class="row g-4">
<div class="col-lg-7"><div class="footer-title">Desenvolvimento do Raciocínio Matemático no Ensino Fundamental I mediado pela História da Matemática</div><p class="mt-2 mb-0">Produto Educacional vinculado ao PPGEN/UNICENTRO.</p></div>
<div class="col-lg-5 text-lg-end"><p class="mb-1">Vanessa Medeiros • <span id="ano"></span></p><a href="/Mestrado/referencias.html">Referências da dissertação</a></div>
</div>
</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/Mestrado/script.js"></script>
</body>
</html>

```

## `script.js`
```javascript
const page = window.location.pathname.split('/').pop() || 'index.html';

document.querySelectorAll('.site-nav .nav-link').forEach(link => {
  const href = link.getAttribute('href');
  if (href === page) link.classList.add('active');
});

const progress = document.createElement('div');
progress.className = 'reading-progress';
document.body.appendChild(progress);

window.addEventListener('scroll', () => {
  const doc = document.documentElement;
  const max = doc.scrollHeight - doc.clientHeight;
  const pct = max > 0 ? (doc.scrollTop / max) * 100 : 0;
  progress.style.width = `${pct}%`;
});

const button = document.createElement('button');
button.id = 'btnTopo';
button.setAttribute('aria-label', 'Voltar ao topo');
button.innerHTML = '<i class="fa-solid fa-arrow-up"></i>';
document.body.appendChild(button);

window.addEventListener('scroll', () => {
  button.style.display = window.scrollY > 450 ? 'block' : 'none';
});

button.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', event => {
    const id = link.getAttribute('href');
    if (!id || id === '#') return;
    const target = document.querySelector(id);
    if (target) {
      event.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

const revealElements = document.querySelectorAll('.reveal');

if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  revealElements.forEach(el => {
    el.classList.add('reveal-ready');
    observer.observe(el);
  });
} else {
  // Fallback: em navegadores sem IntersectionObserver, o conteúdo permanece visível.
  revealElements.forEach(el => el.classList.add('visible'));
}

const year = document.getElementById('ano');
if (year) year.textContent = new Date().getFullYear();

```

## `style.css`
```css
:root {
  --ink: #1f2a44;
  --ink-2: #32415f;
  --paper: #fbf7ee;
  --paper-2: #f2eadc;
  --cream: #fffdf8;
  --gold: #d79b2f;
  --gold-2: #f2c66d;
  --teal: #2f7a77;
  --teal-2: #dcefed;
  --blue: #315c8c;
  --rose: #a85750;
  --line: rgba(31, 42, 68, 0.12);
  --shadow: 0 18px 45px rgba(31, 42, 68, 0.10);
  --radius: 22px;
}

* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body {
  margin: 0;
  font-family: "Inter", "Segoe UI", Arial, sans-serif;
  color: var(--ink);
  background: var(--cream);
  line-height: 1.7;
}

a { color: var(--blue); text-decoration: none; }
a:hover { color: var(--teal); }
img { max-width: 100%; height: auto; }

.reading-progress {
  position: fixed;
  inset: 0 auto auto 0;
  height: 4px;
  width: 0;
  background: linear-gradient(90deg, var(--gold), var(--teal));
  z-index: 2000;
}

.site-nav {
  background: rgba(31, 42, 68, 0.96);
  backdrop-filter: blur(10px);
}
.site-nav .navbar-brand {
  color: #fff;
  font-weight: 800;
  letter-spacing: .3px;
}
.site-nav .brand-mark {
  display: inline-grid;
  place-items: center;
  width: 40px;
  height: 40px;
  margin-right: .55rem;
  border-radius: 12px;
  background: linear-gradient(135deg, var(--gold), var(--gold-2));
  color: var(--ink);
}
.site-nav .nav-link {
  color: rgba(255,255,255,.82) !important;
  font-weight: 600;
  margin-left: .3rem;
  border-radius: 999px;
  padding: .55rem .8rem !important;
}
.site-nav .nav-link:hover,
.site-nav .nav-link.active {
  color: #fff !important;
  background: rgba(255,255,255,.12);
}

.hero {
  position: relative;
  overflow: hidden;
  padding: 6.5rem 0 5rem;
  background:
    radial-gradient(circle at 15% 15%, rgba(215,155,47,.20), transparent 30%),
    radial-gradient(circle at 85% 20%, rgba(47,122,119,.18), transparent 30%),
    linear-gradient(180deg, #fffdf8 0%, #f8f1e5 100%);
}
.hero::after {
  content: "";
  position: absolute;
  inset: 0;
  pointer-events: none;
  opacity: .24;
  background-image: radial-gradient(rgba(31,42,68,.15) 1px, transparent 1px);
  background-size: 22px 22px;
}
.hero .container { position: relative; z-index: 1; }
.eyebrow {
  display: inline-flex;
  align-items: center;
  gap: .55rem;
  padding: .4rem .8rem;
  border-radius: 999px;
  background: #fff;
  border: 1px solid var(--line);
  box-shadow: 0 8px 25px rgba(31,42,68,.06);
  color: var(--teal);
  font-weight: 800;
  text-transform: uppercase;
  font-size: .78rem;
  letter-spacing: .08em;
}
.hero h1,
.page-hero h1 {
  font-family: Georgia, "Times New Roman", serif;
  font-weight: 800;
  color: var(--ink);
  letter-spacing: -.03em;
}
.hero h1 { font-size: clamp(2.45rem, 5vw, 4.6rem); line-height: 1.03; }
.hero .lead { color: var(--ink-2); max-width: 720px; font-size: 1.15rem; }
.hero-visual {
  position: relative;
  padding: 1rem;
}
.hero-visual::before {
  content: "";
  position: absolute;
  inset: 6% 4% 2% 12%;
  background: linear-gradient(145deg, rgba(215,155,47,.18), rgba(47,122,119,.16));
  filter: blur(2px);
  border-radius: 35% 65% 45% 55% / 55% 40% 60% 45%;
  transform: rotate(-4deg);
}
.hero-visual img { position: relative; z-index: 1; filter: drop-shadow(0 18px 25px rgba(31,42,68,.14)); }

.btn-primary-custom,
.btn-outline-custom {
  border-radius: 999px;
  padding: .8rem 1.25rem;
  font-weight: 800;
  transition: .2s ease;
}
.btn-primary-custom {
  background: var(--ink);
  color: #fff;
  border: 1px solid var(--ink);
}
.btn-primary-custom:hover { background: var(--teal); border-color: var(--teal); color: #fff; transform: translateY(-2px); }
.btn-outline-custom {
  color: var(--ink);
  background: rgba(255,255,255,.7);
  border: 1px solid var(--line);
}
.btn-outline-custom:hover { background: #fff; color: var(--teal); transform: translateY(-2px); }

.section { padding: 5rem 0; }
.section-soft { background: var(--paper); }
.section-dark {
  background: var(--ink);
  color: #fff;
}
.section-title {
  font-family: Georgia, "Times New Roman", serif;
  font-weight: 800;
  font-size: clamp(2rem, 3vw, 3rem);
  margin-bottom: 1rem;
  color: var(--ink);
}
.section-dark .section-title { color: #fff; }
.section-subtitle { color: var(--ink-2); max-width: 780px; }
.section-dark .section-subtitle { color: rgba(255,255,255,.78); }

.kicker {
  color: var(--teal);
  text-transform: uppercase;
  letter-spacing: .12em;
  font-weight: 900;
  font-size: .78rem;
}

.feature-card,
.info-card,
.task-card,
.resource-card,
.stat-card {
  height: 100%;
  background: #fff;
  border: 1px solid var(--line);
  border-radius: var(--radius);
  box-shadow: 0 10px 30px rgba(31,42,68,.06);
}
.feature-card,
.info-card,
.resource-card,
.stat-card { padding: 1.6rem; }
.feature-card { transition: transform .2s ease, box-shadow .2s ease; }
.feature-card:hover { transform: translateY(-5px); box-shadow: var(--shadow); }
.icon-orb {
  display: inline-grid;
  place-items: center;
  width: 58px;
  height: 58px;
  border-radius: 18px;
  margin-bottom: 1rem;
  font-size: 1.45rem;
  color: var(--ink);
  background: var(--paper-2);
}
.icon-orb.teal { background: var(--teal-2); color: var(--teal); }
.icon-orb.gold { background: #faedcf; color: #9a6614; }
.icon-orb.rose { background: #f6e2df; color: var(--rose); }
.icon-orb.blue { background: #e3ebf4; color: var(--blue); }

.concept-flow {
  position: relative;
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 1rem;
  align-items: stretch;
}
.concept-flow::before {
  content: "";
  position: absolute;
  top: 50%;
  left: 8%;
  right: 8%;
  height: 2px;
  background: linear-gradient(90deg, var(--gold), var(--teal));
  z-index: 0;
}
.flow-step {
  position: relative;
  z-index: 1;
  padding: 1.3rem 1rem;
  text-align: center;
  border-radius: 18px;
  background: #fff;
  border: 1px solid var(--line);
  box-shadow: 0 10px 25px rgba(31,42,68,.07);
  font-weight: 800;
}
.flow-step small { display: block; margin-top: .35rem; color: var(--ink-2); font-weight: 500; }
.flow-step .num {
  display: inline-grid;
  place-items: center;
  width: 34px;
  height: 34px;
  border-radius: 50%;
  background: var(--ink);
  color: #fff;
  margin-bottom: .6rem;
}

.bridge-card {
  border-radius: 26px;
  padding: 2rem;
  background: linear-gradient(135deg, #fff, #f6efe3);
  border: 1px solid var(--line);
  box-shadow: var(--shadow);
}
.bridge-arrow {
  font-size: 2rem;
  color: var(--gold);
}

.page-hero {
  padding: 4.3rem 0 3.8rem;
  background:
    linear-gradient(135deg, rgba(215,155,47,.15), rgba(47,122,119,.10)),
    var(--paper);
  border-bottom: 1px solid var(--line);
}
.page-hero p { color: var(--ink-2); font-size: 1.08rem; max-width: 820px; }

.pill-row { display: flex; flex-wrap: wrap; gap: .55rem; }
.pill {
  display: inline-flex;
  align-items: center;
  gap: .4rem;
  padding: .42rem .72rem;
  border-radius: 999px;
  background: var(--paper-2);
  color: var(--ink);
  border: 1px solid var(--line);
  font-size: .9rem;
  font-weight: 700;
}

.timeline {
  position: relative;
  padding-left: 2rem;
}
.timeline::before {
  content: "";
  position: absolute;
  left: .55rem;
  top: .6rem;
  bottom: .6rem;
  width: 2px;
  background: linear-gradient(var(--gold), var(--teal));
}
.timeline-item {
  position: relative;
  padding: 0 0 1.8rem 1rem;
}
.timeline-item::before {
  content: "";
  position: absolute;
  left: -1.86rem;
  top: .4rem;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: #fff;
  border: 4px solid var(--teal);
}

.rm-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 1rem;
}
.rm-card {
  padding: 1.5rem;
  border-radius: 22px;
  background: #fff;
  border: 1px solid var(--line);
  box-shadow: 0 10px 28px rgba(31,42,68,.06);
}
.rm-card strong { display: block; font-size: 1.16rem; margin-bottom: .55rem; }
.rm-link {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: .55rem;
  margin-top: 1rem;
  font-weight: 800;
  color: var(--teal);
}

.process-table {
  overflow: hidden;
  border-radius: 20px;
  border: 1px solid var(--line);
  background: #fff;
}
.process-row {
  display: grid;
  grid-template-columns: 190px 1fr 1fr;
  border-bottom: 1px solid var(--line);
}
.process-row:last-child { border-bottom: 0; }
.process-row > div { padding: 1.1rem 1.2rem; }
.process-row.head { background: var(--ink); color: #fff; font-weight: 800; }
.process-name { font-weight: 900; color: var(--ink); background: var(--paper); }
.process-row.head .process-name { color: #fff; background: transparent; }

.hm-callout {
  border-left: 6px solid var(--gold);
  padding: 1.3rem 1.4rem;
  border-radius: 16px;
  background: #fff9eb;
}

.task-card { overflow: hidden; transition: transform .2s ease, box-shadow .2s ease; }
.task-card:hover { transform: translateY(-5px); box-shadow: var(--shadow); }
.task-art {
  height: 190px;
  display: grid;
  place-items: center;
  padding: 1.2rem;
  background: linear-gradient(135deg, #f7edd7, #e6f2f1);
  border-bottom: 1px solid var(--line);
}
.task-art img { max-height: 160px; }
.task-body { padding: 1.5rem; }
.task-meta { display: flex; flex-wrap: wrap; gap: .5rem; margin: 1rem 0; }
.task-meta span {
  padding: .36rem .65rem;
  border-radius: 999px;
  background: var(--paper);
  border: 1px solid var(--line);
  font-size: .84rem;
  font-weight: 700;
}

.resource-card h3 { font-size: 1.1rem; }
.resource-card .resource-type {
  display: inline-block;
  margin-bottom: .75rem;
  color: var(--teal);
  font-size: .78rem;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: .09em;
}

.reference-list { display: grid; gap: .9rem; }
.reference-item {
  padding: 1rem 1.2rem;
  background: #fff;
  border: 1px solid var(--line);
  border-radius: 16px;
}
.reference-item strong { color: var(--ink); }

.quote-panel {
  position: relative;
  padding: 2rem;
  border-radius: 24px;
  background: var(--ink);
  color: #fff;
  overflow: hidden;
}
.quote-panel::after {
  content: "∑";
  position: absolute;
  right: 1rem;
  bottom: -2rem;
  font-family: Georgia, serif;
  font-size: 10rem;
  color: rgba(255,255,255,.06);
}
.quote-panel p { position: relative; z-index: 1; font-size: 1.15rem; margin: 0; }

.stat-card .stat-number {
  font-size: 2rem;
  font-weight: 900;
  color: var(--teal);
}

.notice {
  padding: 1rem 1.2rem;
  border-radius: 16px;
  background: #eef7f5;
  border: 1px solid rgba(47,122,119,.24);
}

.site-footer {
  padding: 3rem 0 2rem;
  background: #172137;
  color: rgba(255,255,255,.84);
}
.site-footer a { color: #fff; }
.site-footer .footer-title { color: #fff; font-weight: 800; }

/* Conteúdo visível por padrão. A animação só é ativada quando o JavaScript carrega corretamente. */
.reveal {
  opacity: 1;
  transform: none;
}
.reveal.reveal-ready {
  opacity: 0;
  transform: translateY(18px);
  transition: opacity .55s ease, transform .55s ease;
}
.reveal.reveal-ready.visible {
  opacity: 1;
  transform: translateY(0);
}

#btnTopo {
  position: fixed;
  right: 22px;
  bottom: 22px;
  width: 48px;
  height: 48px;
  border: 0;
  border-radius: 50%;
  background: var(--ink);
  color: #fff;
  box-shadow: 0 10px 28px rgba(31,42,68,.25);
  display: none;
  z-index: 1200;
}
#btnTopo:hover { background: var(--teal); }

@media (max-width: 991.98px) {
  .hero { padding-top: 4.2rem; }
  .hero-visual { margin-top: 2rem; }
  .concept-flow { grid-template-columns: 1fr; }
  .concept-flow::before { display: none; }
  .rm-grid { grid-template-columns: 1fr; }
  .process-row { grid-template-columns: 1fr; }
  .process-row.head { display: none; }
  .process-name { border-bottom: 1px solid var(--line); }
}

@media (max-width: 575.98px) {
  .section { padding: 3.5rem 0; }
  .hero h1 { font-size: 2.45rem; }
  .page-hero { padding: 3.2rem 0; }
}

```

## `tarefas.html`
```html
<!DOCTYPE html>

<html lang="pt-BR">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<meta content="Tarefa A multiplicação egípcia dos grãos, descrita e analisada na dissertação." name="description"/>
<title>Tarefa | HM + RM</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"/>
<link href="/Mestrado/style.css" rel="stylesheet"/>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark site-nav sticky-top">
<div class="container">
<a class="navbar-brand d-flex align-items-center" href="/Mestrado/index.html"><span class="brand-mark"><i class="fa-solid fa-square-root-variable"></i></span>HM + RM</a>
<button aria-label="Abrir menu" class="navbar-toggler" data-bs-target="#menu" data-bs-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="menu">
<ul class="navbar-nav ms-auto align-items-lg-center">
<li class="nav-item"><a class="nav-link" href="/Mestrado/index.html">Início</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/apresentacao.html">Apresentação</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/historia.html">História da Matemática</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/raciocinio.html">Raciocínio Matemático</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/tarefas.html">Tarefa</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/saiba-mais.html">Aprofundamento</a></li>
<li class="nav-item"><a class="nav-link" href="/Mestrado/referencias.html">Referências</a></li>
</ul>
</div>
</div>
</nav>
<header class="page-hero"><div class="container reveal"><span class="eyebrow"><i class="fa-solid fa-file-pen"></i> Tarefa analisada</span><h1 class="display-4 mt-3">A multiplicação egípcia dos grãos</h1><p class="mt-3 mb-0">Nesta versão da dissertação, a tarefa descrita e analisada articula um contexto associado à matemática egípcia, dobramentos sucessivos e situações que permitem diferentes estratégias de resolução.</p></div></header>
<main>
<section class="section"><div class="container"><div class="row g-5 align-items-center">
<div class="col-lg-7 reveal"><div class="kicker">Organização matemática</div><h2 class="section-title">Dobrar, decompor, compor e justificar</h2><p>A tarefa explora a identificação de regularidades por meio de uma sequência de dobramentos sucessivos, relacionando o número de sacos à quantidade de sementes. Conforme a dissertação, os conteúdos contemplados incluem multiplicação como adição de parcelas iguais, decomposição numérica e propriedade distributiva, em um contexto histórico associado à matemática egípcia.</p><p>As questões foram organizadas para não indicar antecipadamente um único procedimento de resolução, preservando a possibilidade de os estudantes mobilizarem estratégias distintas.</p><div class="task-meta"><span>Multiplicação</span><span>Decomposição numérica</span><span>Propriedade distributiva</span><span>Dobamentos sucessivos</span></div><a class="btn btn-primary-custom mt-3" href="https://docs.google.com/document/d/1Sf8WB6jUWCjGmMc2X2b2POQvGP9R8B7WmqAP4ciJRTY/edit?usp=sharing" rel="noopener" target="_blank">Abrir a tarefa <i class="fa-solid fa-arrow-up-right-from-square ms-2"></i></a></div>
<div class="col-lg-5 reveal"><div class="task-card"><div class="task-art"><img alt="Representação visual dos dobramentos 1, 2, 4 e 8" src="/Mestrado/imagens/papiro-egipcio.svg"/></div><div class="task-body"><div class="kicker">Raciocínio em foco</div><h3 class="h4 mt-2">Conjecturar, generalizar e justificar</h3><p class="mb-0">A elaboração da tarefa considera princípios voltados à variedade de estratégias, ao uso de representações e à reflexão sobre os processos de raciocínio.</p></div></div></div>
</div></div></section>
<section class="section section-soft"><div class="container"><div class="row g-5">
<div class="col-lg-5 reveal"><div class="kicker">Princípios de elaboração</div><h2 class="section-title">Características consideradas na construção das tarefas</h2><p>O percurso metodológico da dissertação informa que as tarefas foram planejadas levando em conta a faixa etária, os conhecimentos esperados para o 5º ano e a intenção de favorecer a manifestação de tipos e processos de RM.</p></div>
<div class="col-lg-7 reveal"><div class="row g-3"><div class="col-md-6"><div class="feature-card"><span class="icon-orb teal"><i class="fa-solid fa-code-branch"></i></span><h3 class="h6">Diferentes estratégias</h3><p class="mb-0">As situações não indicam previamente um único procedimento de resolução.</p></div></div><div class="col-md-6"><div class="feature-card"><span class="icon-orb gold"><i class="fa-solid fa-shapes"></i></span><h3 class="h6">Diferentes representações</h3><p class="mb-0">As questões podem favorecer variadas formas de organizar, registrar e comunicar as ideias matemáticas.</p></div></div><div class="col-md-6"><div class="feature-card"><span class="icon-orb rose"><i class="fa-solid fa-lightbulb"></i></span><h3 class="h6">Generalização</h3><p class="mb-0">Os princípios específicos destacam a observação de semelhanças, diferenças, padrões e propriedades.</p></div></div><div class="col-md-6"><div class="feature-card"><span class="icon-orb blue"><i class="fa-solid fa-scale-balanced"></i></span><h3 class="h6">Justificação</h3><p class="mb-0">As tarefas podem solicitar razões apoiadas em coerência lógica, representações, propriedades, exemplos genéricos ou outras formas de justificação.</p></div></div></div></div>
</div></div></section>
<section class="section"><div class="container"><div class="row g-5 align-items-start">
<div class="col-lg-6 reveal"><div class="kicker">O que foi observado na experiência</div><h2 class="section-title">Tipos e processos mobilizados pelos estudantes</h2><p>Na análise apresentada na dissertação, os estudantes formularam conjecturas ao explorar estratégias de composição e decomposição de números, justificaram escolhas com base em coerência lógica e manifestaram uma generalização inicial ao reconhecer o padrão de “dobrar e combinar”.</p><p>Essas manifestações foram relacionadas, respectivamente, aos raciocínios abdutivo, dedutivo e indutivo.</p></div>
<div class="col-lg-6 reveal"><div class="quote-panel"><p>A análise evidencia que diferentes formas de raciocínio podem emergir no decorrer de uma mesma tarefa, articuladas às estratégias, às explicações e às interações produzidas pelos estudantes.</p></div><div class="pill-row mt-4"><span class="pill">Abdutivo → conjecturar</span><span class="pill">Dedutivo → justificar</span><span class="pill">Indutivo → generalizar</span></div></div>
</div></div></section>
<section class="section section-dark"><div class="container"><div class="row g-5"><div class="col-lg-5 reveal"><div class="kicker" style="color:var(--gold-2)">Produto Educacional</div><h2 class="section-title">Cada tarefa é acompanhada por elementos de apoio ao professor</h2></div><div class="col-lg-7 reveal"><div class="timeline"><div class="timeline-item"><h3 class="h5 text-white">Contexto histórico em HQ</h3><p class="mb-0 text-white-50">Integra o episódio histórico à situação matemática proposta.</p></div><div class="timeline-item"><h3 class="h5 text-white">Objetivos de aprendizagem</h3><p class="mb-0 text-white-50">Explicitam as aprendizagens matemáticas pretendidas.</p></div><div class="timeline-item"><h3 class="h5 text-white">Orientações e encaminhamentos</h3><p class="mb-0 text-white-50">Apoiam a organização e o desenvolvimento da tarefa.</p></div><div class="timeline-item"><h3 class="h5 text-white">Relações com o RM</h3><p class="mb-0 text-white-50">Indicam possibilidades de mobilização de tipos e processos de Raciocínio Matemático.</p></div></div></div></div></div></section>
</main>
<footer class="site-footer">
<div class="container">
<div class="row g-4">
<div class="col-lg-7"><div class="footer-title">Desenvolvimento do Raciocínio Matemático no Ensino Fundamental I mediado pela História da Matemática</div><p class="mt-2 mb-0">Produto Educacional vinculado ao PPGEN/UNICENTRO.</p></div>
<div class="col-lg-5 text-lg-end"><p class="mb-1">Vanessa Medeiros • <span id="ano"></span></p><a href="/Mestrado/referencias.html">Referências da dissertação</a></div>
</div>
</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/Mestrado/script.js"></script>
</body>
</html>

```
