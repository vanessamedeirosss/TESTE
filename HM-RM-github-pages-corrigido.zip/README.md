# HM-RM — versão revisada

Site do Produto Educacional vinculado à dissertação **Desenvolvimento do Raciocínio Matemático no Ensino Fundamental I mediado pela História da Matemática**.

## Critério desta revisão

A redação das páginas foi revista para permanecer **estritamente fundamentada na versão da dissertação fornecida**. Foram retiradas formulações, recomendações e descrições que não estavam explicitamente sustentadas pelo referencial teórico, pelo percurso metodológico ou pela análise da tarefa presentes no texto.

O site mantém o foco em:

- História da Matemática como tendência metodológica;
- Raciocínio Matemático, seus tipos e processos;
- princípios de elaboração de tarefas;
- Produto Educacional para o 5º ano do Ensino Fundamental;
- tarefa **A multiplicação egípcia dos grãos**, que é a tarefa descrita e analisada nesta versão da dissertação.

A seção “Aula em três fases” permanece excluída.

## Arquivos

- `index.html` — página inicial;
- `apresentacao.html` — questão, objetivo e composição do Produto Educacional;
- `historia.html` — referencial de História da Matemática;
- `raciocinio.html` — conceituação, tipos e processos de RM;
- `tarefas.html` — tarefa descrita e analisada na versão da dissertação;
- `saiba-mais.html` — organização dos autores do próprio referencial da dissertação;
- `referencias.html` — referências presentes na dissertação;
- `style.css` — estilos;
- `script.js` — interações visuais;
- `imagens/` — elementos visuais em SVG.

## Publicação no GitHub Pages

Substitua os arquivos do repositório pelos desta pasta, mantenha a pasta `imagens` e exclua qualquer arquivo antigo relacionado a “aula em três fases”.


## Correção dos links no GitHub Pages

Esta versão foi preparada especificamente para o endereço `https://vanessamedeirosss.github.io/Mestrado/`. Os links internos usam o prefixo `/Mestrado/`, evitando que **Saiba mais** e **Referências** quebrem por causa do caminho relativo.

É indispensável manter `referencias.html` e `saiba-mais.html` na raiz do repositório, junto com `index.html`. Também foram incluídas pastas de compatibilidade `referencias/` e `saiba-mais/` com redirecionamento.
